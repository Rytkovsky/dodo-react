import "./styles/global.css";
import { Header } from "../layouts/Header/Header";
import { Main } from "../layouts/Main/Main";
import { Footer } from "../layouts/Footer/Footer";
import { Basket } from "../pages/Basket/Basket";
// import {ModalNew} from "..//components/ModalNew/ModalNew"

function App() {
  // const [isOpenModalNew, setIsOpenModalNew] = useState(false);
  return (
    <>
      {/* <Header />
      <Basket />
      <Main />
      <Footer /> */}
    </>
  );
}

export default App;
