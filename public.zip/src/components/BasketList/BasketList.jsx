import s from "./BasketList.module.scss";

export const BasketList = ({ children }) => {
  return (
    <>
      <ul>{children}</ul>
    </>
  );
};
